% Parameters
fs = 1000;               % Sampling rate (Hz)
f = 10;                  % Frequency of the sinusoidal signal (Hz)
n = 5000;                % Number of samples
t = (0:n-1) / fs;        % Time vector

% Generate noisy sinusoidal signal
signal = sin(2 * pi * f * t);    % Original sinusoidal signal
noise = 0.5 * randn(1, n);       % Gaussian noise
noisy_signal = signal + noise;   % Noisy signal

% Adaptive filter parameters
filter_order = 5;                % Filter order for FIR filter
eta = 0.05;                      % Learning rate
weights = zeros(1, filter_order);% Initial weights for the filter
w_bias = 0;                      % Initialize bias

% Outputs and errors
output = zeros(1, n);
error = zeros(1, n);

% Training process parameters
epochs = 100;                    % Number of epochs
error_threshold = 1e-6;
previous_total_error = 0;

% Store total errors for each epoch
errors_per_epoch = zeros(1, epochs);

for epoch = 1:epochs
    total_error = 0;
    for i = filter_order + 1:n
        % Create the input vector for the filter (last 'filter_order' samples of noisy signal)
        x = flip(noisy_signal(i - filter_order:i - 1));  % Reverse order of the input vector

        % Compute filter output with bias
        prediction = dot(weights, x) + w_bias;

        % Compute error (difference between prediction and original signal)
        error(i) = signal(i) - prediction;
        total_error = total_error + error(i)^2;

        % Update weights and bias using LMS algorithm
        weights = weights + eta * error(i) * x;
        w_bias = w_bias + eta * error(i);

        % Store output
        output(i) = prediction;
    end

    % Store total error for this epoch
    errors_per_epoch(epoch) = total_error;

    % Stop if convergence criterion is met
    if abs(total_error - previous_total_error) < error_threshold
        fprintf('Network converged in %d epochs\n', epoch);
        break;
    end
    previous_total_error = total_error;
end

% Display final weights and bias
disp('weights:');
disp(weights);
disp('bias:');
disp(w_bias);

% Plot original signal, noisy signal, and filtered signal
figure;
subplot(3, 1, 1);
plot(t, signal, 'DisplayName', 'Original Signal');
title('Original Signal');
legend;

subplot(3, 1, 2);
plot(t, noisy_signal, 'DisplayName', 'Noisy Signal');
title('Noisy Signal');
legend;

subplot(3, 1, 3);
plot(t, output, 'DisplayName', 'Filtered Signal');
hold on;
plot(t, signal, '--', 'DisplayName', 'Original Signal (Reference)');
title('Adaptive Filter Output with ADALINE');
legend;
xlabel('Time (seconds)');

% Plot error per epoch
figure;
plot(1:epoch, errors_per_epoch(1:epoch), '-o');
xlabel('Epochs');
ylabel('Total Error');
title('Error per Epoch');
grid on;
