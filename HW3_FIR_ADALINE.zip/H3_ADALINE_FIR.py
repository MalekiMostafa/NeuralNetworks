import numpy as np
import matplotlib.pyplot as plt

# Signal parameters
fs = 1000            # Sampling rate (Hz)
f = 10               # Frequency of the sinusoidal signal (Hz)
n = 500          # Number of samples
t = np.arange(n) / fs  # Time vector

# Generate noisy sinusoidal signal
signal = np.sin(2 * np.pi * f * t)         # Original sinusoidal signal
noise = 0.5 * np.random.randn(n)           # Gaussian noise
noisy_signal = signal + noise              # Noisy signal

# Adaptive filter parameters
filter_order = 5         # Filter order for FIR filter
eta = 0.05                # Adjusted learning rate
weights = np.zeros(filter_order)   # Initial weights for the filter
w_bias = 0.0                 # Initialize bias

# Outputs and errors
output = np.zeros(n)
error = np.zeros(n)

# Training process
epochs = 100                # Increased epochs
error_threshold = 1e-6
previous_total_error = 0

# Store total errors for each epoch
errors_per_epoch = []

for epoch in range(epochs):
    total_error = 0
    for i in range(filter_order, n):
        # Create the input vector for the filter (last 'filter_order' samples of noisy signal)
        x = noisy_signal[i - filter_order:i][::-1]

        # Compute filter output with bias
        prediction = np.dot(weights, x) + w_bias

        # Compute error (difference between prediction and original signal)
        error[i] = signal[i] - prediction
        total_error += error[i] ** 2

        # Update weights using LMS algorithm
        weights += eta * error[i] * x
        w_bias += eta * error[i]  # Update bias

        # Store output
        output[i] = prediction

    # Append total error for this epoch
    errors_per_epoch.append(total_error)

    # Stop if convergence criterion is met
    if abs(total_error - previous_total_error) < error_threshold:
        print(f"Network converged in {epoch + 1} epochs")
        break

    previous_total_error = total_error
print('weights:', weights)
print('bias:', w_bias)

# Plot original signal, noisy signal, and filtered signal
plt.figure(figsize=(12, 8))

plt.subplot(3, 1, 1)
plt.plot(t, signal, label="Original Signal")
plt.title("Original Signal")
plt.legend()

plt.subplot(3, 1, 2)
plt.plot(t, noisy_signal, label="Noisy Signal")
plt.title("Noisy Signal")
plt.legend()

plt.subplot(3, 1, 3)
plt.plot(t, output, label="Filtered Signal")
plt.plot(t, signal, '--', label="Original Signal (Reference)")
plt.title("Adaptive Filter Output with ADALINE")
plt.legend()

plt.xlabel("Time (seconds)")
plt.tight_layout()
plt.show()

# Plot error per epoch
plt.figure()
plt.plot(range(1, len(errors_per_epoch) + 1), errors_per_epoch, marker='o')
plt.xlabel('Epochs')
plt.ylabel('Total Error')
plt.title('Error per Epoch')
plt.grid(True)
plt.show()
